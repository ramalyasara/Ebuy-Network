﻿$(document).ready(function () {
    $('#startDate,#endDate').datepicker({
        format: 'yyyy-mm-dd'
    });
});

