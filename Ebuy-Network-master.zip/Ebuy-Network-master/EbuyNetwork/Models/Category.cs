﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EbuyNetwork.Models
{
    public class Category
    {
        public int id { set; get; }
        public string name { set; get; }
        public int item_count { set; get; }

        public Category(){

        }


    }
}